jQuery(document).ready(function($) {

	'use strict';
      
      $('#form-submit .date').datepicker({
      });

      let owl = $("#owl-suiteroom");

        owl.owlCarousel({
          
          pagination : true,
          paginationNumbers: false,
          autoPlay: 6000, // putar otomatis menjadi 3 detik per set
          items : 1, //10 objek berukuruan 1000px pada bagian width browser
          itemsDesktop : [1000,1], //5 objek berukuran antara 1000px dan 901px 
          itemsDesktopSmall : [900,1], //berukuran antara 900px dan 601 px 
          itemsTablet: [600,1], //2 objek berukuran antara 600 dan 0
          itemsMobile : false // itemsMobile dinonaktifkan
          
      });


      let owl = $("#owl-mostvisited");

        owl.owlCarousel({
          
          pagination : true,
          paginationNumbers: false,
          autoPlay: 6000, //putar otomatis menjadi 3 detik per set
          items : 4, //10 objek berukuruan 1000px pada bagian width browser
          itemsDesktop : [1000,4], //5 objek berukuran antara 1000px dan 901px 
          itemsDesktopSmall : [900,2], // berukuran antara 900px dan 601 px 
          itemsTablet: [600,1], //2 objek berukuran antara 600 dan 0
          itemsMobile : false // itemsMobile dinonaktifkan
          
      });


        // penyusunan bagian grup rekomendasi
        $('.recommendedgroup > div').hide();
        $('.recommendedgroup > div:first-of-type').show();
        $('.tabs a').click(function(e){
          e.preventDefault();
            let $this = $(this),
            tabgroup = '#'+$this.parents('.tabs').data('recommendedgroup'),
            others = $this.closest('li').siblings().children('a'),
            target = $this.attr('href');
        others.removeClass('active');
        $this.addClass('active');
        $(tabgroup).children('div').hide();
        $(target).show();
      
        })
        // penyusunan Bagian Tampilan cuaca


        $('.weathergroup > div').hide();
        $('.weathergroup > div:first-of-type').show();
        $('.tabs a').click(function(e){
          e.preventDefault();
            let $this = $(this),
            tabgroup = '#'+$this.parents('.tabs').data('weathergroup'),
            others = $this.closest('li').siblings().children('a'),
            target = $this.attr('href');
        others.removeClass('active');
        $this.addClass('active');
        $(tabgroup).children('div').hide();
        $(target).show();
      
        })


        $('.tabgroup > div').hide();
        $('.tabgroup > div:first-of-type').show();
        $('.tabs a').click(function(e){
          e.preventDefault();
            let $this = $(this),
            tabgroup = '#'+$this.parents('.tabs').data('tabgroup'),
            others = $this.closest('li').siblings().children('a'),
            target = $this.attr('href');
        others.removeClass('active');
        $this.addClass('active');
        $(tabgroup).children('div').hide();
        $(target).show();
      
        })



        $(".pop-button").click(function () {
            $(".pop").fadeIn(300);
            
        });

        $(".pop > span").click(function () {
            $(".pop").fadeOut(300);
        });


        $(window).on("scroll", function() {
            if($(window).scrollTop() > 100) {
                $(".header").addClass("active");
            } else {
                //meghapus background dan merubah background menjadi transparan
               $(".header").removeClass("active");
            }
        });


	// filter project
    	$('.projects-holder').mixitup({
            effects: ['fade','grayscale'],
            easing: 'snap',
            transitionSpeed: 400
        });



});
